1. 
The purpose of this program is to give people a brief history of typing and to help them type faster, because it has become a crucial skill in today's age

2.
You can use almost any modern computer to run this game. 
Make sure to have python version 3.6 or higher installed
Operating System: Windows 10/Mac works

3. 
To check the credits, click on credits.txt
To check the source code, click on source.txt
To run the program, click on "blitss.py"
In the program, you have five options. 
You can view our lesson on typing and how to type faster. 
Then, you can take the quiz and see how much you remembered. 
You can then test and improve your typing skills in our game. 
To exit the program, you can click the exit button on the main menu or just close the window

4.
You should be able to see the whole window, so just drag the window upward. 
Make sure you do not move any files from the doloaded folder to anywhere else. If you do, download the folder again. 
Make sure you have pygame installed to run this program
If audio does not work, download VLC media player. Then redownload the files